const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const port = 9000;
const openAiSecret = process.env.openAiSecret;
console.log(openAiSecret);

// OpenAI API URL
const OPENAI_API_URL = 'https://api.openai.com';

// Options for proxy middleware
const proxyOptions = {
  target: OPENAI_API_URL,
  changeOrigin: true,
  onProxyReq: (proxyReq, req, res) => {
    // 移除 'x-forwarded-for' 和 'x-real-ip' 头，确保不传递原始客户端 IP 地址等信息
    proxyReq.removeHeader('x-forwarded-for');
    proxyReq.removeHeader('x-real-ip');
  },
  onProxyRes: function (proxyRes, req, res) {
    proxyRes.headers['Access-Control-Allow-Origin'] = '*';
  }
};

// Add the proxy middleware
app.use('/', createProxyMiddleware(proxyOptions));

// Start the server
app.listen(port, () => {
  console.log('Example app listening at http://localhost:${port}');
});